$(document).ready(function () {

    var animationName = 'animated shake';
    var animationEnd = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';

    $('a.my_button').click(function () {

        $('.my_shake').addClass(animationName).one(animationEnd, function () {
            $(this).removeClass(animationName);
        });

    });

});