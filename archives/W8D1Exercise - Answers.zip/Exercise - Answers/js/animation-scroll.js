$(document).ready(function () {

    $(window).scroll(function() {

        var verticalScroll = $(this).scrollTop();

        if(verticalScroll > 20) {

            $('.navbar-default').css('background-color', 'white');
        }
        

    });
    
    $(window).scroll(function() {

        var verticalScroll = $(this).scrollTop();

        if(verticalScroll = 250) {

            $('#sandwhich').addClass('flipInX');
            $('#sandwhich').removeClass('hide_me');
        }
        

    });
    
    $(window).scroll(function() {

        var verticalScroll = $(this).scrollTop();

        if(verticalScroll >= 550) {

            $('#my_1').addClass('fadeInDownBig');
            $('#my_1').removeClass('hide_me');
            $('#my_2').addClass('fadeInRightBig');
            $('#my_2').removeClass('hide_me');
            $('#my_3').addClass('fadeInUpBig');
            $('#my_3').removeClass('hide_me');
            $('#my_4').addClass('fadeInLeftBig');
            $('#my_4').removeClass('hide_me');
        }

    });
    
    $(window).scroll(function() {

        var verticalScroll = $(this).scrollTop();

        if(verticalScroll >= 600) {

            $('.wisdom').addClass('fadeIn');
        }

    });
    
});